import sqlite3
from datetime import datetime


def get_db(name="main.db"):
    """This function creates a connection object for the sqlite3 database. It also calls the create_tables function to
    ensure tables are created if they do not already exist."""
    db = sqlite3.connect(name)
    create_tables(db)
    return db


def create_tables(db):
    """Creates habits table
    name: stores the habit's name
    description: stores further details on habit
    periodicity: stores an integer based on the habit's expected periodicity
    Creates tracker table
    date: stores the date of each check-off
    habitName: stores the habit's name, linked to column name of the habits tabla
    currentCount: stores the number of check-offs that make up the current streak for the habit
    """
    cur = db.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS habits(
    name TEXT PRIMARY KEY,
    description TEXT,
    periodicity INT)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS tracker(
    date TEXT,
    habitName TEXT,
    currentCount INT,
    FOREIGN KEY (habitName) REFERENCES habits(name))""")

    db.commit()


def add_habit(db, name, description, periodicity):
    """Creates a habit by adding data to habits table. Does not add data to the tracker table."""
    cur = db.cursor()
    try:
        cur.execute("INSERT INTO habits VALUES (?, ?, ?)", (name, description, periodicity))
        db.commit()
        print(f"{name} has been created successfully.")
    except sqlite3.IntegrityError:
        print(f"Error: a habit named {name} already exists.")


def delete_habit(db, name):
    """Deletes a habit from the habits table, as well as all associated events from the tracker table."""
    cur = db.cursor()
    cur.execute("DELETE FROM habits WHERE name=?", (name,))
    cur.execute("DELETE FROM tracker WHERE habitName=?", (name,))
    db.commit()


def increment_counter(db, name, count, event_date=None):
    """Adds event to the tracker table."""
    cur = db.cursor()
    if not event_date:
        event_date = str(datetime.today())
    cur.execute("INSERT INTO tracker VALUES (?, ?, ?)", (event_date, name, count))
    db.commit()


def get_flattened_habit_list(db, name):
    """Queries the habits table of the sqlite3 database to fetch all data for all habits.
    Flattens the resulting object to a list and returns the list."""
    cur = db.cursor()
    cur.execute("SELECT * FROM habits WHERE name=?", (name,))
    habit_tuples = cur.fetchall()
    habit_list = []
    for row in habit_tuples:
        for item in row:
            habit_list.append(item)
    return habit_list


def get_tracker_data(db, name, periodicity):
    """Queries the tracker table of the sqlite3 database to fetch all events matching the parameters specified.
    It returns a list of tuples."""
    cur = db.cursor()
    if not name:
        if not periodicity:
            cur.execute("SELECT * FROM tracker")
            tracker_data = cur.fetchall()
        else:
            cur.execute("SELECT * FROM tracker WHERE habitName IN (SELECT name FROM habits WHERE periodicity=?)", (periodicity,))
            tracker_data = cur.fetchall()
    else:
        cur.execute("SELECT * FROM tracker WHERE habitName=?", (name,))
        tracker_data = cur.fetchall()
    return tracker_data


def get_flattened_habit_names(db, periodicity):
    """Queries the sqlite3 habits database to fetch only the names of habits matching the parameters specified.
    Flattens the resulting list of tuples to a list and returns it."""
    cur = db.cursor()
    if not periodicity:
        cur.execute("SELECT name FROM habits")
    else:
        cur.execute("SELECT name FROM habits WHERE periodicity=?", (periodicity,))
    habit_names_tuple = cur.fetchall()
    habit_names_list = []
    for row in habit_names_tuple:
        for item in row:
            habit_names_list.append(item)
    return habit_names_list


def get_periodicity(db, name):
    """Returns the expected periodicity of a specified habit."""
    habit_list = get_flattened_habit_list(db, name)
    periodicity = habit_list.pop()
    return periodicity


def get_tracker_list(db, name, periodicity):
    """Flattens the list of tuples returned by get_tracker_data() to a list and returns it."""
    tlist = []
    tracker_data = get_tracker_data(db, name, periodicity)
    for row in tracker_data:
        for item in row:
            tlist.append(item)
    return tlist


def get_tracked_habit_set(db):
    """Queries the sqlite3 database for all habit names contained in the tracker table.
    Flattens the resulting object to a list and converts it into a set, which it
    returns."""
    cur = db.cursor()
    cur.execute("SELECT habitName FROM tracker")
    tracked_habit_names_tuples = cur.fetchall()
    tracked_habit_names_list = []
    for row in tracked_habit_names_tuples:
        for item in row:
            tracked_habit_names_list.append(item)
    tracked_habit_names_set = set(tracked_habit_names_list)
    return tracked_habit_names_set


def get_count(db, name):
    """Returns the count of the current streak for a specific habit.
    If no events for that habit are found, it returns 0."""
    tlist = get_tracker_list(db, name, None)
    if tlist:
        return tlist.pop()
    else:
        return 0
