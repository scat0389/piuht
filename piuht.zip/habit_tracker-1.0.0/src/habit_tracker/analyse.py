from datetime import datetime
from operator import itemgetter
from more_itertools import pairwise
from db import get_flattened_habit_names, get_tracked_habit_set, get_tracker_data, get_tracker_list, get_periodicity


def reformat_as_joined_string(it):
    """Reformats an iterable to a joined string."""
    sep = ", "
    joined_string = sep.join(it)
    return joined_string


def check_periodicity(db, name):
    """Checks whether the time elapsed between the current and the previous habit check-off exceeds the
    expected periodicity of the habit."""
    tlist = get_tracker_list(db, name, None)
    if tlist:
        last_date = (datetime.strptime(tlist[-3], '%Y-%m-%d %H:%M:%S.%f')).replace(microsecond=0)
        event_date = datetime.today().replace(microsecond=0)
        delta = ((event_date - last_date).total_seconds())
        return delta
    else:
        return 0.0


def count_habits(db, periodicity):
    """Checks number of habits matching parameters."""
    countable_habits = get_flattened_habit_names(db, periodicity)
    return len(countable_habits)


def habits_never_incremented(db, periodicity) -> set | str:
    """Returns habits on habit list (if any) that do not have events recorded on the tracker table."""
    habit_names_set = set(get_flattened_habit_names(db, periodicity))
    tracked_habits_name_set = get_tracked_habit_set(db)
    habits_never_incremented_ = habit_names_set.difference(tracked_habits_name_set)
    if not habits_never_incremented_:
        habits_never_incremented_ = "You have checked off all your habits at least once."
        return habits_never_incremented_
    else:
        return habits_never_incremented_


def sort_and_format_tracker_data(db, name, periodicity):
    """This is a generator that sorts the data returned by get_tracker_data by name and converts the event
    dates to datetime objects. """
    tracker_data = get_tracker_data(db, name, periodicity)
    sorted_list_of_tuples = sorted(tracker_data, key=itemgetter(1))
    formatted_list_of_tuples = []
    for event in sorted_list_of_tuples:
        event_time = datetime.strptime(event[0], '%Y-%m-%d %H:%M:%S.%f')
        new_tuple = (event_time, *event[1:])
        formatted_list_of_tuples.append(new_tuple)
    streak_list = []
    for a, b in pairwise(formatted_list_of_tuples):
        streak_list.append(a)
        if b[1] != a[1]:
            yield streak_list
            streak_list = []
    try:
        streak_list.append(formatted_list_of_tuples[-1])
    except IndexError:
        pass
    yield streak_list


def sorted_formatted_list(db, name, periodicity):
    """This calls the generator sort_and_format_tracker_data to create a list of lists of tuples where each
    sublist represents the events for a specific habit and each tuple an event date."""
    list_of_streaks = list(sort_and_format_tracker_data(db, name, periodicity))
    return list_of_streaks


def generate_streak_lists(db, arg_name, arg_periodicity):
    """This generator creates separate streak lists based on sorted_formatted_list by determining whether the period
    elapsed between two event dates exceeds the specified periodicity."""
    streaks_by_habit = sorted_formatted_list(db, arg_name, arg_periodicity)
    streaks = []
    for s_list in streaks_by_habit:
        name = arg_name
        periodicity = arg_periodicity
        if not name:
            name = s_list[0][1]
        if not periodicity:
            periodicity = get_periodicity(db, name)
        if periodicity == 1:
            for a, b in pairwise(s_list):
                streaks.append(a)
                if (b[0] - a[0]).total_seconds() > (periodicity * (24 + 3) * 3600): # 3 hours leniency
                    yield streaks
                    streaks = []
        elif periodicity == 7:
            for a, b in pairwise(s_list):
                streaks.append(a)
                if (b[0] - a[0]).total_seconds() > ((periodicity + 3) * 24 * 3600): # 3 days leniency
                    yield streaks
                    streaks = []
        try:
            streaks.append(s_list[-1])
        except IndexError:
            pass
        yield streaks
        streaks = []


def list_of_streak_lists(db, name, periodicity):
    """This calls the generator generate_streak_lists to create a super list containing the streak lists for the
    habits matching the parameters."""
    streak_list = list(generate_streak_lists(db, name, periodicity))
    return streak_list


def number_of_streaks(db, name, periodicity):
    """This counts the streaks matching parameters."""
    number = len(list_of_streak_lists(db, name, periodicity))
    return number


def lengths_of_streaks(db, name, periodicity):
    """Checks the lengths of streaks matching parameters."""
    streaks = list_of_streak_lists(db, name, periodicity)
    lengths = []
    if streaks:
        for streak in streaks:
            lengths.append(len(streak))
    else:
        lengths = []
    return lengths


def maximum_length(db, name):
    """Returns the first maximum value contained by the list of lengths of streaks returned by lengths_of_streaks()."""
    lengths = lengths_of_streaks(db, name, None)
    maximum = max(lengths)
    return maximum


def indices_of_longest_streaks(db, name, periodicity):
    """Returns a list of indices of all streaks the length of which equals the maximum value for length."""
    lengths = lengths_of_streaks(db, name, periodicity)
    if lengths:
        indices = [i for i, x in enumerate(lengths) if x == max(lengths)]
    else:
        indices = []
    return indices


def all_longest_streaks(db, name, periodicity):
    """Returns all streaks the length of which matches the indices of longest streaks."""
    indices = indices_of_longest_streaks(db, name, periodicity)
    streaks = list_of_streak_lists(db, name, periodicity)
    longest_streaks = []
    if indices:
        for i in indices:
            longest_streaks.append(streaks[i])
        return longest_streaks
    else:
        raise ValueError


def average_streak(db, name, periodicity) -> float:
    """Returns average streak length for streaks matching parameters. Returns 0.0 if no streaks are found."""
    sum_streaks = sum(lengths_of_streaks(db, name, periodicity))
    len_streaks = len(lengths_of_streaks(db, name, periodicity))
    if len_streaks:
        average = sum_streaks/len_streaks
    else:
        average = 0.0
    return average
