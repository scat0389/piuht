import questionary
from db import get_db, get_count, get_periodicity, get_flattened_habit_names, delete_habit
from habit import Habit
from analyse import check_periodicity, habits_never_incremented, count_habits, \
    reformat_as_joined_string, average_streak, \
    number_of_streaks, maximum_length, all_longest_streaks
from datetime import datetime


def cli():
    db = get_db()

    stop = False
    while not stop:
        choice = questionary.select("What do you want to do?",
                                    choices=["Create habit",
                                             "Check off habit",
                                             "Analyse habits",
                                             "Delete habit",
                                             "Exit"]).ask()

        if choice == "Create habit":
            name = questionary.text("Which habit would you like to form?").ask()
            desc = questionary.text("Please provide further details on your desired habit.").ask()
            choice = questionary.select(message="How often do you wish to repeat this habit?",
                                        choices=["Daily", "Weekly"]).ask()
            if choice == "Daily":
                periodicity = 1
            elif choice == "Weekly":
                periodicity = 7
            else:
                raise RuntimeError("Unexpected situation in program")
            count = 0
            habit = Habit(name, desc, periodicity, count)
            habit.store(db)

        elif choice == "Check off habit":
            try:
                name = questionary.select("Which habit would you like to check off?",
                                          choices=get_flattened_habit_names(db, None)).ask()
                current_count = get_count(db, name)
                periodicity = get_periodicity(db, name)
                habit = Habit(name, "no description", periodicity, current_count)
                delta = check_periodicity(db, name)
                if periodicity == 1:
                    if 0 <= delta <= periodicity * (24 + 3) * 3600: #3 hours leniency
                        current_count += 1
                        habit.add_event(db, current_count)
                        if current_count > 1:
                            print(f"Current streak {name}: {current_count} increments.")
                        else:
                            print(f"You have checked off {name} for the first time.")
                    else:
                        current_count = 1
                        habit.add_event(db, current_count)
                        print(f"You have started a new streak for {name}.")
                elif periodicity == 7:
                    if 0 <= delta <= ((periodicity + 3) * 24) * 3600: #3 days leniency
                        current_count += 1
                        habit.add_event(db, current_count)
                        if current_count > 1:
                            print(f"Current streak {name}: {current_count} increments.")
                        else:
                            print(f"You have checked off {name} for the first time.")
                    else:
                        current_count = 1
                        habit.add_event(db, current_count)
                        print(f"You have started a new streak for {name}.")
            except ValueError:
                print("You have not created any habits yet.")

        elif choice == "Analyse habits":
            choice = questionary.select("What do you want to analyse?",
                                        choices=["Overall trends",
                                                 "Individual habits"]).ask()
            if choice == "Individual habits":
                try:
                    name = questionary.select("Which habit would you like to analyse?",
                                              choices=get_flattened_habit_names(db, None)).ask()
                    count = get_count(db, name)
                    if count > 1:
                        print(f"Current streak length: {name} has been checked off {count} times.")
                    elif count == 1:
                        print(f"Current streak length: {name} has been checked off once.")
                    else:
                        print(f"You have never checked off {name}.")
                    choice = questionary.select(f"What else would you like to know about {name}?",
                                                choices=["Longest streak length",
                                                         "Average streak length"]).ask()
                    if choice == "Longest streak length":
                        longest_streak = maximum_length(db, name)
                        if longest_streak > 1:
                            print(f"During your longest streak, {name} was checked off {longest_streak} times.")
                        elif longest_streak == 1:
                            print(f"During your longest streak, {name} was checked off once.")
                        else:
                            print(f"You have never checked off {name}.")
                    elif choice == "Average streak length":
                        average = average_streak(db, name, None)
                        print(f"Your average streak length for {name} is {average} check-offs.")
                    else:
                        pass
                except ValueError:
                    print("You have not created any habits yet.")
            else:
                choice = questionary.select("Choose from the following options:",
                                            choices=["List habits",
                                                     "Count habits",
                                                     "Calculate streaks",
                                                     "Exit"]).ask()
                if choice == "List habits":
                    choice = questionary.select("List...",
                                                choices=["All habits",
                                                         "Daily habits",
                                                         "Weekly habits",
                                                         "Habits created but never checked off"]).ask()
                    if choice == "All habits":
                        all_habits = get_flattened_habit_names(db, None)
                        if not all_habits:
                            print("You have not created any habits yet.")
                        else:
                            print(reformat_as_joined_string(all_habits))
                    elif choice == "Daily habits":
                        daily_habits = get_flattened_habit_names(db, 1)
                        if not daily_habits:
                            print("You have not created any daily habits yet.")
                        else:
                            print(reformat_as_joined_string(daily_habits))
                    elif choice == "Weekly habits":
                        weekly_habits = get_flattened_habit_names(db, 7)
                        if not weekly_habits:
                            print("You have not created any weekly habits yet.")
                        else:
                            print(reformat_as_joined_string(weekly_habits))
                    elif choice == "Habits created but never checked off":
                        choice = questionary.select("List...",
                                                    choices=["All habits never checked off",
                                                             "Daily habits never checked off",
                                                             "Weekly habits never checked off"]).ask()
                        if choice == "All habits never checked off":
                            try:
                                print(reformat_as_joined_string(habits_never_incremented(db, None)))
                            except ValueError:
                                print("You have not created any habits yet.")
                        elif choice == "Daily habits never checked off":
                            try:
                                print(reformat_as_joined_string(habits_never_incremented(db, 1)))
                            except ValueError:
                                print("You have not created any habits yet.")
                            except TypeError:
                                print("You have checked off all your daily habits at least once.")
                        elif choice == "Weekly habits never checked off":
                            try:
                                print(reformat_as_joined_string(habits_never_incremented(db, 7)))
                            except ValueError:
                                print("You have not created any habits yet.")
                            except TypeError:
                                print("You have checked off all your weekly habits at least once.")
                elif choice == "Count habits":
                    choice = questionary.select("Count...",
                                                choices=["All habits",
                                                         "Daily habits",
                                                         "Weekly habits"]).ask()
                    if choice == "All habits":
                        all_habits = count_habits(db, None)
                        print(f"You have created {all_habits} habits.")
                    elif choice == "Daily habits":
                        daily_habits = count_habits(db, 1)
                        print(f"You have created {daily_habits} daily habits.")
                    elif choice == "Weekly habits":
                        weekly_habits = count_habits(db, 7)
                        print(f"You have created {weekly_habits} weekly habits.")
                elif choice == "Calculate streaks":
                    choice = questionary.select("Calculate...",
                                                choices=["Longest overall streak",
                                                         "Longest streak (daily habits)",
                                                         "Longest streak (weekly habits)",
                                                         "Average streak length",
                                                         "Overall number of streaks"]).ask()
                    if choice == "Longest overall streak":
                        longest_streak = all_longest_streaks(db, None, None)
                        if len(longest_streak) == 1:
                            print("During your longest streak...")
                            for streak in longest_streak:
                                length = len(streak)
                                habit = streak[0][1]
                                beginning = datetime.strftime(streak[0][0], '%d-%m-%Y')
                                end = datetime.strftime(streak[-1][-3], '%d-%m-%Y')
                                print(f"... you checked off {habit} {length} times. The streak began "
                                      f"on {beginning} and ended on {end}.")
                        else:
                            print("Your longest streaks:")
                            try:
                                for streak in longest_streak:
                                    length = len(streak)
                                    habit = streak[0][1]
                                    beginning = datetime.strftime(streak[0][0], '%d-%m-%Y')
                                    end = datetime.strftime(streak[-1][-3], '%d-%m-%Y')
                                    print(f"You checked off {habit} {length} times between {beginning} and {end}.")
                            except ValueError:
                                print("You have not started any streaks yet.")
                    elif choice == "Longest streak (daily habits)":
                        longest_streak = all_longest_streaks(db, None, 1)
                        if len(longest_streak) == 1:
                            print("During your longest streak...")
                            for streak in longest_streak:
                                length = len(streak)
                                habit = streak[0][1]
                                beginning = datetime.strftime(streak[0][0], '%d-%m-%Y')
                                end = datetime.strftime(streak[-1][-3], '%d-%m-%Y')
                                print(
                                    f"... you checked off {habit} {length} times. The streak began "
                                    f"on {beginning} and ended on {end}.")
                        else:
                            print("Your longest streaks:")
                            try:
                                for streak in longest_streak:
                                    length = len(streak)
                                    habit = streak[0][1]
                                    beginning = datetime.strftime(streak[0][0], '%d-%m-%Y')
                                    end = datetime.strftime(streak[-1][-3], '%d-%m-%Y')
                                    print(f"You checked off {habit} {length} times between {beginning} and {end}.")
                            except ValueError:
                                print("You have not started any streaks yet.")
                    elif choice == "Longest streak (weekly habits)":
                        longest_streak = all_longest_streaks(db, None, 7)
                        if len(longest_streak) == 1:
                            print("During your longest streak...")
                            for streak in longest_streak:
                                length = len(streak)
                                habit = streak[0][1]
                                beginning = datetime.strftime(streak[0][0], '%d-%m-%Y')
                                end = datetime.strftime(streak[-1][-3], '%d-%m-%Y')
                                print(
                                    f"... you checked off {habit} {length} times. The streak began "
                                    f"on {beginning} and ended on {end}.")
                        else:
                            print("Your longest streaks:")
                            try:
                                for streak in longest_streak:
                                    length = len(streak)
                                    habit = streak[0][1]
                                    beginning = datetime.strftime(streak[0][0], '%d-%m-%Y')
                                    end = datetime.strftime(streak[-1][-3], '%d-%m-%Y')
                                    print(f"You checked off {habit} {length} times between {beginning} and {end}.")
                            except ValueError:
                                print("You have not started any streaks yet.")
                    elif choice == "Average streak length":
                        choice = questionary.select("Calculate...", choices=["Overall average length",
                                                                             "Average length (daily)",
                                                                             "Average length (weekly)"]).ask()
                        if choice == "Overall average length":
                            average = average_streak(db, None, None)
                            print(f"Your overall average streak length is {average} check-offs.")
                        elif choice == "Average length (daily)":
                            average = average_streak(db, None, 1)
                            print(f"Your average streak length for daily habits is {average} check-offs.")
                        elif choice == "Average length (weekly)":
                            average = average_streak(db, None, 7)
                            print(f"Your average streak length for weekly habits is {average} check-offs.")
                    elif choice == "Overall number of streaks":
                        number = number_of_streaks(db, None, None)
                        habits = count_habits(db, None)
                        print(f"Having created {habits} habits, you have started {number} streaks so far.")
        elif choice == "Delete habit":
            try:
                name = questionary.select("Which habit would you like to delete?",
                                          choices=get_flattened_habit_names(db, None)).ask()
                confirm = questionary.confirm(f"Are you sure you would like to delete {name}?").ask()
                if confirm:
                    delete_habit(db, name)
                    print(f"{name} has been deleted.")
            except ValueError:
                print("You have not created any habits yet.")
        else:
            print("Bye!")
            stop = True


if __name__ == '__main__':
    cli()
