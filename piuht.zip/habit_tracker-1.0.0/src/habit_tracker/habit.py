from db import add_habit, increment_counter


class Habit:
    def __init__(self, name: str, description: str, periodicity, count):
        """Habit class, to define habits and expected periodicity of repetitions
        param name: the name of the habit
        param description: the description of the habit
        param periodicity: the maximum interval at which the habit is to be repeated, expressed as an integer
        param count: the number of check-offs making up the habit's current streak
        """
        self.name = name
        self.description = description
        self.periodicity = periodicity
        self.count = count

    def store(self, db):
        add_habit(db, self.name, self.description, self.periodicity)

    def add_event(self, db, current_count, date: str = None):
        increment_counter(db, self.name, current_count, date)
