from datetime import datetime
from db import get_db, add_habit, increment_counter, get_flattened_habit_list, get_tracker_data, \
    get_flattened_habit_names, get_tracker_list, get_periodicity, get_tracked_habit_set, get_count
from analyse import check_periodicity, habits_never_incremented, count_habits, list_of_streak_lists, number_of_streaks, \
    lengths_of_streaks, maximum_length, indices_of_longest_streaks, all_longest_streaks, average_streak


class TestHabit:
    def setup_method(self):
        self.db = get_db("test.db")
        add_habit(self.db, "Make the bed", "Make the bed every morning", 1)
        add_habit(self.db, "Journal", "Journal every evening to reflect on the day past", 1)
        add_habit(self.db, "Drink water", "Drink a glass of water first thing every morning", 1)
        add_habit(self.db, "Clear Inbox", "Clear my inbox at the end of each working day", 1)
        add_habit(self.db, "Meditate", "Meditate for 15 Minutes", 1)
        add_habit(self.db, "Read", "Read a book every week", 7)
        add_habit(self.db, "Cycle 20km", "Cycle at least 20 km", 7)
        add_habit(self.db, "Plan meals", "Plan meals for the upcoming week", 7)

        increment_counter(self.db, "Drink water", 1, "2024-06-03 07:52:10.114285")
        increment_counter(self.db, "Make the bed", 1, "2024-06-03 08:15:10.114285")
        increment_counter(self.db, "Clear Inbox", 1, "2024-06-03 17:16:21.114285")
        increment_counter(self.db, "Journal", 1, "2024-06-03 21:52:10.114285")
        increment_counter(self.db, "Drink water", 2, "2024-06-04 08:05:14.327893")
        increment_counter(self.db, "Make the bed", 2, "2024-06-04 08:11:07.327893")
        increment_counter(self.db, "Journal", 2, "2024-06-04 22:11:07.327893")
        increment_counter(self.db, "Make the bed", 3, "2024-06-05 08:12:31.453768")
        increment_counter(self.db, "Journal", 3, "2024-06-05 21:48:31.453768")
        increment_counter(self.db, "Drink water", 1, "2024-06-06 07:48:31.453768")
        increment_counter(self.db, "Journal", 4, "2024-06-06 23:02:09.129876")
        increment_counter(self.db, "Drink water", 2, "2024-06-07 08:02:09.129876")
        increment_counter(self.db, "Journal", 5, "2024-06-07 22:52:18.342343")
        increment_counter(self.db, "Drink water", 3, "2024-06-08 06:52:18.342343")
        increment_counter(self.db, "Plan meals", 1, "2024-06-08 11:02:21.114285")
        increment_counter(self.db, "Journal", 6, "2024-06-08 22:32:23.879878")
        increment_counter(self.db, "Drink water", 4, "2024-06-09 07:32:23.879878")
        increment_counter(self.db, "Cycle 20km", 1, "2024-06-09 15:16:21.114285")
        increment_counter(self.db, "Journal", 7, "2024-06-09 23:00:11.676687")
        increment_counter(self.db, "Drink water", 5, "2024-06-10 08:00:11.676687")
        increment_counter(self.db, "Make the bed", 1, "2024-06-10 08:15:09.129876")
        increment_counter(self.db, "Journal", 8, "2024-06-10 21:57:14.675387")
        increment_counter(self.db, "Drink water", 6, "2024-06-11 07:57:14.675387")
        increment_counter(self.db, "Make the bed", 2, "2024-06-11 08:13:18.342343")
        increment_counter(self.db, "Drink water", 7, "2024-06-12 08:08:11.124537")
        increment_counter(self.db, "Make the bed", 3, "2024-06-12 08:09:23.879878")
        increment_counter(self.db, "Drink water", 8, "2024-06-13 07:44:41.234567")
        increment_counter(self.db, "Make the bed", 4, "2024-06-13 08:10:11.676687")
        increment_counter(self.db, "Drink water", 9, "2024-06-14 06:59:54.676687")
        increment_counter(self.db, "Make the bed", 5, "2024-06-14 08:13:14.675387")
        increment_counter(self.db, "Journal", 1, "2024-06-14 22:08:11.124537")
        increment_counter(self.db, "Drink water", 10, "2024-06-15 08:00:11.676687")
        increment_counter(self.db, "Journal", 2, "2024-06-15 22:44:41.234567")
        increment_counter(self.db, "Make the bed", 1, "2024-06-16 08:14:11.124537")
        increment_counter(self.db, "Cycle 20km", 2, "2024-06-16 16:32:21.114285")
        increment_counter(self.db, "Drink water", 1, "2024-06-17 07:18:44.676687")
        increment_counter(self.db, "Make the bed", 2, "2024-06-17 08:12:41.234567")
        increment_counter(self.db, "Journal", 1, "2024-06-17 21:59:54.676687")
        increment_counter(self.db, "Drink water", 2, "2024-06-18 07:21:33.676687")
        increment_counter(self.db, "Make the bed", 3, "2024-06-18 08:07:54.676687")
        increment_counter(self.db, "Journal", 2, "2024-06-18 22:00:11.676687")
        increment_counter(self.db, "Drink water", 3, "2024-06-19 08:01:11.676687")
        increment_counter(self.db, "Make the bed", 4, "2024-06-19 08:12:11.676687")
        increment_counter(self.db, "Journal", 3, "2024-06-19 22:18:44.676687")
        increment_counter(self.db, "Drink water", 4, "2024-06-20 08:08:10.676687")
        increment_counter(self.db, "Make the bed", 5, "2024-06-20 08:03:44.676687")
        increment_counter(self.db, "Journal", 4, "2024-06-20 21:21:33.676687")
        increment_counter(self.db, "Drink water", 5, "2024-06-21 08:11:11.676687")
        increment_counter(self.db, "Make the bed", 6, "2024-06-21 08:13:33.676687")
        increment_counter(self.db, "Journal", 5, "2024-06-21 22:01:11.676687")
        increment_counter(self.db, "Drink water", 6, "2024-06-22 08:14:09.676687")
        increment_counter(self.db, "Make the bed", 7, "2024-06-22 08:14:11.676687")
        increment_counter(self.db, "Plan meals", 1, "2024-06-22 10:57:21.114285")
        increment_counter(self.db, "Drink water", 7, "2024-06-23 07:07:53.676687")
        increment_counter(self.db, "Make the bed", 8, "2024-06-23 08:12:10.676687")
        increment_counter(self.db, "Journal", 1, "2024-06-23 22:08:10.676687")
        increment_counter(self.db, "Make the bed", 9, "2024-06-24 08:10:11.676687")
        increment_counter(self.db, "Journal", 2, "2024-06-24 22:11:11.676687")
        increment_counter(self.db, "Make the bed", 10, "2024-06-25 08:11:09.676687")
        increment_counter(self.db, "Journal", 3, "2024-06-25 22:14:09.676687")
        increment_counter(self.db, "Drink water", 1, "2024-06-26 07:47:03.676687")
        increment_counter(self.db, "Journal", 4, "2024-06-26 22:07:53.676687")
        increment_counter(self.db, "Drink water", 2, "2024-06-27 08:04:11.676687")
        increment_counter(self.db, "Journal", 5, "2024-06-27 21:47:03.676687")
        increment_counter(self.db, "Drink water", 3, "2024-06-28 07:08:11.676687")
        increment_counter(self.db, "Make the bed", 1, "2024-06-28 08:07:53.676687")
        increment_counter(self.db, "Journal", 6, "2024-06-28 22:04:11.676687")
        increment_counter(self.db, "Drink water", 4, "2024-06-29 08:05:11.676687")
        increment_counter(self.db, "Make the bed", 2, "2024-06-29 08:14:03.676687")
        increment_counter(self.db, "Plan meals", 2, "2024-06-29 11:18:21.114285")
        increment_counter(self.db, "Journal", 7, "2024-06-29 22:08:11.676687")
        increment_counter(self.db, "Drink water", 5, "2024-06-30 08:05:11.676687")
        increment_counter(self.db, "Make the bed", 3, "2024-06-30 08:08:11.676687")
        increment_counter(self.db, "Journal", 8, "2024-06-30 23:05:11.676687")

    def test_get_flattened_habit_list(self):
        assert ['Clear Inbox', 'Clear my inbox at the end of each working day', 1, ] == get_flattened_habit_list(
            self.db, 'Clear Inbox')

    def test_get_tracker_data_specific_habit(self):
        assert [('2024-06-03 17:16:21.114285', 'Clear Inbox', 1)] == get_tracker_data(self.db, 'Clear Inbox', None)

    def test_get_tracker_data_periodicity(self):
        assert [('2024-06-08 11:02:21.114285', 'Plan meals', 1), ('2024-06-09 15:16:21.114285', 'Cycle 20km', 1),
                ('2024-06-16 16:32:21.114285', 'Cycle 20km', 2), ('2024-06-22 10:57:21.114285', 'Plan meals', 1),
                ('2024-06-29 11:18:21.114285', 'Plan meals', 2)] == get_tracker_data(self.db, None, 7)

    def test_get_flattened_habit_names(self):
        assert ['Clear Inbox', 'Cycle 20km', 'Drink water', 'Journal', 'Make the bed', 'Meditate', 'Plan meals',
                'Read'] == get_flattened_habit_names(self.db, None)

    def test_get_periodicity(self):
        assert 1 == get_periodicity(self.db, "Journal")

    def test_get_tracker_list_specific_habit(self):
        assert ['2024-06-03 17:16:21.114285', 'Clear Inbox', 1] == get_tracker_list(self.db, 'Clear Inbox', None)

    def test_get_tracker_list_periodicity(self):
        assert ['2024-06-08 11:02:21.114285', 'Plan meals', 1, '2024-06-09 15:16:21.114285', 'Cycle 20km', 1,
                '2024-06-16 16:32:21.114285', 'Cycle 20km', 2, '2024-06-22 10:57:21.114285', 'Plan meals', 1,
                '2024-06-29 11:18:21.114285', 'Plan meals', 2] == get_tracker_list(self.db, None, 7)

    def test_get_tracked_habit_set(self):
        assert {'Clear Inbox', 'Journal', 'Plan meals', 'Drink water', 'Make the bed',
                'Cycle 20km'} == get_tracked_habit_set(self.db)

    def test_get_count(self):
        assert 8 == get_count(self.db, 'Journal')

    def test_check_periodicity(self):
        assert (datetime.today().replace(microsecond=0)
                - (datetime.fromisoformat('2024-06-30 23:05:11.676687')).replace(microsecond=0)
                ).total_seconds() == check_periodicity(self.db, 'Journal')

    def test_count_habits(self):
        assert 8 == count_habits(self.db, None)

    def test_habits_never_incremented(self):
        assert {'Meditate', 'Read'} == habits_never_incremented(self.db, None)

    def test_habits_never_incremented_weekly(self):
        assert {'Read'} == habits_never_incremented(self.db, 7)

    def test_list_of_streak_lists(self):
        assert [[(datetime(2024, 6, 3, 17, 16, 21, 114285),
                  'Clear Inbox', 1)]] == list_of_streak_lists(self.db, 'Clear Inbox', None)

    def test_number_of_streaks_specific_habit(self):
        assert 4 == number_of_streaks(self.db, 'Make the bed', None)

    def test_lengths_of_streaks_specific_habit(self):
        assert [3, 5, 10, 3] == lengths_of_streaks(self.db, 'Make the bed', None)

    def test_lengths_of_streaks_periodicity(self):
        assert [2, 1, 2] == lengths_of_streaks(self.db, None, 7)

    def test_maximum_length(self):
        assert 10 == maximum_length(self.db, 'Make the bed')

    def test_indices_of_longest_streaks(self):
        assert [3, 12] == indices_of_longest_streaks(self.db, None, None)

    def test_all_longest_streaks(self):
        assert [[(datetime(2024, 6, 6, 7, 48, 31, 453768), 'Drink water', 1),
                 (datetime(2024, 6, 7, 8, 2, 9, 129876), 'Drink water', 2),
                 (datetime(2024, 6, 8, 6, 52, 18, 342343), 'Drink water', 3),
                 (datetime(2024, 6, 9, 7, 32, 23, 879878), 'Drink water', 4),
                 (datetime(2024, 6, 10, 8, 0, 11, 676687), 'Drink water', 5),
                 (datetime(2024, 6, 11, 7, 57, 14, 675387), 'Drink water', 6),
                 (datetime(2024, 6, 12, 8, 8, 11, 124537), 'Drink water', 7),
                 (datetime(2024, 6, 13, 7, 44, 41, 234567), 'Drink water', 8),
                 (datetime(2024, 6, 14, 6, 59, 54, 676687), 'Drink water', 9),
                 (datetime(2024, 6, 15, 8, 0, 11, 676687), 'Drink water', 10)],
                [(datetime(2024, 6, 16, 8, 14, 11, 124537), 'Make the bed', 1),
                 (datetime(2024, 6, 17, 8, 12, 41, 234567), 'Make the bed', 2),
                 (datetime(2024, 6, 18, 8, 7, 54, 676687), 'Make the bed', 3),
                 (datetime(2024, 6, 19, 8, 12, 11, 676687), 'Make the bed', 4),
                 (datetime(2024, 6, 20, 8, 3, 44, 676687), 'Make the bed', 5),
                 (datetime(2024, 6, 21, 8, 13, 33, 676687), 'Make the bed', 6),
                 (datetime(2024, 6, 22, 8, 14, 11, 676687), 'Make the bed', 7),
                 (datetime(2024, 6, 23, 8, 12, 10, 676687), 'Make the bed', 8),
                 (datetime(2024, 6, 24, 8, 10, 11, 676687), 'Make the bed', 9),
                 (datetime(2024, 6, 25, 8, 11, 9, 676687), 'Make the bed', 10)]
                ] == all_longest_streaks(self.db, None, None)

    def test_average_streak_periodicity(self):
        assert 1.6666666666666667 == average_streak(self.db, None, 7)

    def test_average_streak_habit(self):
        assert 5.25 == average_streak(self.db, 'Make the bed', None)

    @staticmethod
    def teardown_method():
        import os
        os.remove("test.db")
